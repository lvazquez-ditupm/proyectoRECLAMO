/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package context.entropy.variance;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Vero
 */
public class IndicatorRenyiCrossEntropyList {
    //Attributes
    private ArrayList<IndicatorRenyiCrossEntropy> _entropyList;
    //Constructors
    public IndicatorRenyiCrossEntropyList(){
        _entropyList = new ArrayList<IndicatorRenyiCrossEntropy>();
    }

    public void addContextAnomalyIndicator(IndicatorRenyiCrossEntropy newIndicatorRenyiCrossEntropy){
        if (newIndicatorRenyiCrossEntropy != null){
            getIndicatorRenyiCrossEntropyList().add((newIndicatorRenyiCrossEntropy));
        }
        else{
            System.out.println("Error: [IndicatorRenyiCrossEntropyList] [addContextAnomalyIndicator] "
                + "Unable to add the indicator partial entropy:" + newIndicatorRenyiCrossEntropy.getIndicatorName());
        }
    }
    public void printIndicatorRenyiCrossEntropyList(){
        Iterator i = getIndicatorRenyiCrossEntropyList().iterator();
        while(i.hasNext()){
            IndicatorRenyiCrossEntropy entropy = (IndicatorRenyiCrossEntropy)i.next();
            System.out.println(entropy.toString());
        }
    }

    public IndicatorRenyiCrossEntropy getExistRenyiCrossEntropyIndicators(String valueName){
        IndicatorRenyiCrossEntropy entropy;
        Iterator i = getIndicatorRenyiCrossEntropyList().iterator();
        while(i.hasNext()){
            entropy = (IndicatorRenyiCrossEntropy)i.next();
            if (entropy.getIndicatorName().equalsIgnoreCase(valueName)){
                return entropy;
            }
        }
        return null;
    }

    public ArrayList<IndicatorRenyiCrossEntropy> getIndicatorRenyiCrossEntropyList(){
        return _entropyList;
    }

    public void setIndicatorRenyiCrossEntropyList(ArrayList<IndicatorRenyiCrossEntropy> value){
        _entropyList = value;
    }


}
