/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package context.entropy.variance;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Vero
 */
public class ContextAnomalyIndicatorList {
    //Attributes
    private ArrayList<ContextAnomalyIndicator> _indicatorList;
    //Constructors
    public ContextAnomalyIndicatorList(){
        _indicatorList = new ArrayList<ContextAnomalyIndicator>();
    }
    
    public void addContextAnomalyIndicator(ContextAnomalyIndicator newContextAnomalyIndicator){
        if (newContextAnomalyIndicator != null){
            getContextAnomalyIndicatorList().add((newContextAnomalyIndicator));
        }
        else{
            System.out.println("Error: [ContextAnomalyIndicatorList] [addContextAnomalyIndicator] "
                + "Unable to add the Context Anomaly Indicator:" + newContextAnomalyIndicator.getIndicatorName());
        }
    }
    public void printContextAnomalyIndicatorList(){
        Iterator i = getContextAnomalyIndicatorList().iterator();
        while(i.hasNext()){
            ContextAnomalyIndicator indicator = (ContextAnomalyIndicator)i.next();
            System.out.println(indicator.toString());
        }
    }

    public ContextAnomalyIndicator getExistContextAnomalyIndicators(String valueName){
        ContextAnomalyIndicator contAnomalyIndicator;
        Iterator i = getContextAnomalyIndicatorList().iterator();
        while(i.hasNext()){
            contAnomalyIndicator = (ContextAnomalyIndicator)i.next();
            if (contAnomalyIndicator.getIndicatorName().equalsIgnoreCase(valueName)){
                return contAnomalyIndicator;
            }
        }
        return null;
    }
    
    public ArrayList<ContextAnomalyIndicator> getContextAnomalyIndicatorList(){
        return _indicatorList;
    }

    public void setContextAnomalyIndicatorList(ArrayList<ContextAnomalyIndicator> value){
        _indicatorList = value;
    }



}
