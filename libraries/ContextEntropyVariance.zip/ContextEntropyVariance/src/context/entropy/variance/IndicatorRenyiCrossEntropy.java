/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package context.entropy.variance;

/**
 *
 * @author Vero
 */
public class IndicatorRenyiCrossEntropy {

    private String _indicatorName;
    private double _entropyValue;
    private double _indicatorWeight;


    // Constructores de la clase
    public IndicatorRenyiCrossEntropy(){
        _indicatorName = null;
        _entropyValue = -1;
        _indicatorWeight = -1;
    }
    public IndicatorRenyiCrossEntropy(String initIndicatorName, double initEntropyValue){
        this._indicatorName = initIndicatorName;
        this._entropyValue = initEntropyValue;
        this._indicatorWeight = 1/9;
    }
    public IndicatorRenyiCrossEntropy(String initIndicatorName, double initEntropyValue, double initIndicatorWeight){
        this._indicatorName = initIndicatorName;
        this._entropyValue = initEntropyValue;
        this._indicatorWeight = initIndicatorWeight;
    }

    //Métodos
    public String getIndicatorName(){
        return _indicatorName;
    }
    public double getEntropyValue(){
        return _entropyValue;
    }
    public double getIndicatorWeight(){
        return _indicatorWeight;
    }
    public void setIndicatorName(String value){
        _indicatorName = value;
    }
    public void setEntropyValue(double value){
        _entropyValue = value;
    }
    public void setIndicatorWeight(double value){
        _indicatorWeight = value;
    }

}
