/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package context.entropy.variance;

/**
 *
 * @author Vero
 */
public class ContextAnomalyIndicator {
    private String _indicatorName;
    private int _indicatorValue;
    private double _indicatorWeight;


    // Constructores de la clase
    public ContextAnomalyIndicator(){
        _indicatorName = null;
        _indicatorValue = -1;
        _indicatorWeight = -1;
    }
    public ContextAnomalyIndicator(String initIndicatorName, int initIndicatorValue){
        this._indicatorName = initIndicatorName;
        this._indicatorValue = initIndicatorValue;
        this._indicatorWeight = 1/9;
    }
    public ContextAnomalyIndicator(String initIndicatorName, int initIndicatorValue, double initIndicatorWeight){
        this._indicatorName = initIndicatorName;
        this._indicatorValue = initIndicatorValue;
        this._indicatorWeight = initIndicatorWeight;
    }
    
    //Métodos
    public String getIndicatorName(){
        return _indicatorName;
    }
    public int getIndicatorValue(){
        return _indicatorValue;
    }
    public double getIndicatorWeight(){
        return _indicatorWeight;
    }
    public void setIndicatorName(String value){
        _indicatorName = value;
    }
    public void setIndicatorValue(int value){
        _indicatorValue = value;
    }
    public void setIndicatorWeight(double value){
        _indicatorWeight = value;
    }
}
